import React from "react";
import Label from "../../../common/Label";
import NameInitials from "../../../common/NameInitials";
import FollowLabel from "../common/FollowLabel";

function ListFirstPart({
  handleFollowChange,
  companyId,
  name,
  field,
  status,
  follow_status,
}) {
  const statusText = status ? "Active" : "Inactive";
  const statusColor = status ? "bg-Darkgold" : "bg-nevy_blue";
  const statusTextColor = status ? "text-Darkgold" : "text-nevy_blue";

  return (
    <div className="flex gap-2 flex-1 flex-row items-center justify-between">
      <div className="flex flex-row items-center justify-start gap-2">
        <NameInitials name={name} bg="5629dc" class_name="w-10 h-10" />
        <div className="flex flex-col items-start justify-center overflow-hidden flex-1">
          <Label
            text={name}
            class_name="text-sm font-bold text-text_b truncate w-full leading-tight"
          />

          <div className="flex flex-1 w-full flex-row text-[8px] font-semibold items-center justify-start gap-3 mt-0.5 uppercase tracking-wide">
            <Label
              as="span"
              text={field}
              class_name="px-1.5 py-0.5 rounded-small bg-lighter text-text_b_l border border-lighter"
            />
            <div className="flex items-center gap-1.5 ml-1">
              <span
                className={`w-1.5 h-1.5 rounded-full ${statusColor}`}
                aria-hidden="true"
              />
              <Label as="span" text={statusText} class_name={statusTextColor} />
            </div>
          </div>
        </div>
      </div>
      <div className="w-fit ml-auto flex items-center justify-center mr-4">
        <FollowLabel
          status={follow_status}
          class_name={"text-[clamp(0.6em,1vw,1em)]"}
          onToggle={() => handleFollowChange(companyId)}
        />
      </div>
    </div>
  );
}

export default ListFirstPart;
