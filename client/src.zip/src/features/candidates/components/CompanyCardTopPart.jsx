import React, { useContext, useState, useEffect } from "react";
import { LoaderCircle } from "lucide-react";
import Label from "../../../common/Label";
import FollowLabel from "../common/FollowLabel";
import GridViewHeader from "./GridViewHeader";
import Image from "../../../common/Image";
import { getInitials } from "../../../../utils/getAvatar";
import { useAuth } from "../../../../hooks/useAuth";

function CompanyCardTopPart({
  handleFollowChange,
  isGrid,
  companyId,
  company,
}) {
  const isActive = company.active;
  // Calculate total open positions from all jobs
  const totalOpenings = company.jobs?.length || 0;
  // Check if company has followers (follow status)
  const hasFollowers = company?.followers && company?.followers?.length > 0;

  // State of the follow and unfollow
  const [followed, setFollowed] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Check user is auth
  const { user } = useAuth();

  // useEffect
  useEffect(() => {
    setFollowed(hasFollowers);
  }, []);

  // toggle follow status : passing the companyId and and the follow status
  const toggle_follow = async (status) => {
    if (!user) return;

    setIsLoading(true);

    const res = await handleFollowChange(companyId, user.id, followed);

    console.log(res);

    res.success && setFollowed((prev) => !prev);

    setIsLoading(false);
  };

  return !isGrid ? (
    <header
      className={`flex gap-2 flex-row w-full items-center justify-start border-b border-lighter/30 pb-3`}
    >
      <div
        className="h-12 w-12 text-white bg-d_blue rounded-small text-xl font-semibold flex items-center justify-center shrink-0 shadow-sm"
        aria-hidden="true"
      >
        <Image link={getInitials(company.company_name || "N/A")} />
      </div>
      <div className="flex flex-col items-start justify-center overflow-hidden flex-1 relative">
        <Label
          text={company.company_name || "N/A"}
          class_name="text-[clamp(1.2em,1vw,1.4em)] font-semibold truncate w-full text-text_b leading-tight"
        />

        <div
          className={`flex items-center gap-1.5 ml-1 absolute right-0 top-0 rounded-full text-sm p-1.5 py-0 ${isActive ? "bg-blue/20" : "bg-red"}`}
        >
          <Label
            text={isActive ? "Active" : "Inactive"}
            class_name={!isActive ? "text-Darkgold" : "text-nevy_blue"}
          />
        </div>

        <div className="flex flex-row text-[10px] font-semibold items-center justify-start gap-2 mt-1 uppercase tracking-wide">
          <Label
            text={company.industry_type || "N/A"}
            class_name="px-2 py-0.5 rounded-small bg-lighter text-text_b_l border border-lighter"
          />

          <div className="w-fit flex items-center justify-center cursor-pointer">
            {isLoading ? (
              <span className="animate-spin">
                <LoaderCircle size={10} />
              </span>
            ) : (
              <button
                disabled={isLoading}
                className={`${followed ? "border border-black/20" : "bg-g_btn text-white"} cursor-pointer rounded-sm p-1`}
                onClick={() => toggle_follow()}
              >
                {followed ? "Unfollow" : "Follow"}
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  ) : (
    <GridViewHeader
      company={company}
      companyId={companyId}
      isActive={isActive}
      hasFollowers={hasFollowers}
      totalOpenings={totalOpenings}
      handleFollowChange={handleFollowChange}
    />
  );
}

export default CompanyCardTopPart;
